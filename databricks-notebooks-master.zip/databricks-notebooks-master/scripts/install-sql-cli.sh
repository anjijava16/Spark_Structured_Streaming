#!/bin/sh
# https://www.npmjs.com/package/sql-cli
# install node (if not yet)
# brew install node

npm install -g sql-cli
