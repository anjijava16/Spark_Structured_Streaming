package knolx.spark

case class Stock(stockName: String, numberOfShares: Int, orderType: String)
