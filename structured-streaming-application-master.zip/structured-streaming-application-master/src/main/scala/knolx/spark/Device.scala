package knolx.spark

case class Device(powerConsumed: Double)
