# 如何在流处理中构建模型

1.construct a machine learning pipieline offline
(involves analysis on historical data to build the machine learning model)

2.uses the model in production on live events(streaming process)



spark ml demo reference:
https://github.com/caroljmcdonald/spark-ml-flightdelay

# 附
Machine Learning Logistics - Model Management in the Real World （eBook）:
https://mapr.com/ebook/machine-learning-logistics/
