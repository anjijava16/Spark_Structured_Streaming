# structured-streaming-avro-demo

Spark 3.0.0 Structured Streaming Kafka Avro demo using the new Avro Datasource. 

## Requirements 

* Kafka: 2.0
* Java 8
* Maven

## Usage

Configure kafka hosts and execute both the ```GeneratorDemo``` and the ```StructuredDemo``` classes.
